function formatDate(userDate) {
  // format from M/D/YYYY to YYYYMMDD
  return userDate
    .split('/')
    .reverse()
    .map((n) => (n.length > 1 ? n : `0${n}`))
    .join('');
}

console.log(formatDate('12/31/2014'));
