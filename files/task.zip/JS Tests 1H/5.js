function endangeredSpecies(continent, species) {
  // Your code goes here
  // got the continent from all uls list
  const theContinent = Array.from(document.querySelectorAll('ul')).find((ul) => ul.getAttribute('data-continent') === continent);
  // got the specie from all lis in the continent ul
  return Array.from(theContinent.querySelectorAll('li')).find((li) => li.getAttribute('data-continent') === species);
}

// Example case
document.body.innerHTML = `<div>
  <ul data-continent="North America">
    <li data-species="California condor">Critically Endangered</li>
    <li data-species="American bison">Near Threatened</li>
  </ul>
  <ul data-continent="Europe">
    <li data-species="Cave bear">Extinct</li>
  </ul>
</div>`;

console.log(endangeredSpecies('North America', 'American bison')); // should print 'Near Threatened'
